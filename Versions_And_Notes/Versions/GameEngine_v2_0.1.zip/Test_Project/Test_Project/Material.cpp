#include "Material.h"

// Konstruktor.
Material::Material()
{
	// 1. Ustawienie jasnosci materialu.
	shininess = 32.0f;
}

// Konstruktor.
Material::Material(float shininess)
{
	// 1. Ustawienie jasnosci materialu.
	this->shininess = shininess;
}

// Zwrocenie jasnosci materialu.
float Material::GetShininess()
{
	return shininess;
}
