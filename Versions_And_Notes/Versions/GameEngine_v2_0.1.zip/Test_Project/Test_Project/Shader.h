#pragma once

#include <GL/glew.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>

#include <glm\gtc\type_ptr.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include "Camera.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "Material.h"
#include <string>

class Shader
{
public:
	// Konstruktory.
	Shader();
	Shader(const char* vertexLocation, const char* fragmentLocation);
	Shader(const char* vertexLocation, const char* geometryLocation, const char* fragmentLocation);

	// Utworzenie shadera.
	void CreateFromFiles(const char* vertexLocation, const char* fragmentLocation);
	void CreateFromFiles(const char* vertexLocation, const char* geometryLocation, const char* fragmentLocation);

	// Uzywanie shadera.
	void UseShader();

	// Uzyskaj lokalizacje uniformu.
	GLuint GetUniformLocation(const GLchar* name);

	// Zalacz wartosc z uniformem macierza o okreslonej nazwie.
	void AttachUniformMatrix4x4(const GLchar* name, glm::mat4 matrix);

	// Zalacz wartosc z uniforme macierza o okreslonej lokalizacji.
	void AttachUniformMatrix4x4(GLuint location, glm::mat4 matrix);

	// Powiaz uniform o okreslonej nazwie  z pojedyncza wartoscia.
	void AttachUniformSingleFloatValue(const GLchar* name, float value);

	// Powiaz uniform o okrelsonej lokalizacji z pojedyncza wartosci.
	void AttachUniformSingleFloatValue(GLuint location, float value);

	// Powiaz uniform o okreslonej nazwie z wekstorem.
	void AttachUniformVector3(const GLchar* name, glm::vec3 vector);

	// Powiaz uniform o okreslonej lokalizacji z wektorem.
	void AttachUniformVector3(GLuint location, glm::vec3 vector);

	// Powiaz jednostke tekstury z probka o okreslonej nazwie.
	void BindTextureSamplerUniformToTextureUnit(const GLchar* name, GLuint id);

	// Powiaz jednostke tekstury z probka o okreslonej lokalizacji.
	void BindTextureSamplerUniformToTextureUnit(GLuint location, GLuint id);

	// Powiaz uniform kamery z kamera.
	void AttachCamera(Camera* camera);

	// Powiaz swiatlo kierunkowe z odpowiednim uniformem o okreslonej nazwie.
	void AttachDirectionalLight(const GLchar* name, DirectionalLight* directionaLight);

	// Powiaz swiatlo punktowe z odpowiednim uniformem o okreslonej nazwie.
	void AttachPointLight(const GLchar* name, PointLight* pointLight);

	// Powiaz swiatlo reflektorowe z odpowiednim uniformem o okreslonej nazwie
	void AttachSpotLight(const GLchar* name, SpotLight* spotLight);

	// Powiazanie materialu z uniformem o okreslonej nazwie.
	void AttachMaterial(const GLchar* name, Material* material);

	// Usuniecie shadera.
	void ClearShader();

	// Wylacz shader.
	void EndUsing();

	// Destruktor.
	~Shader();

private:
	GLuint shaderID; // Identyfikator shadera.

	// Wczytanie pliku do lancucha znakow.
	std::string ReadFile(const char* fileLocation);

	// Dodanie shadera do programu z shaderami.
	void AddShader(GLuint program, const char* shaderCode, GLenum shaderType);

	// Kompiluj shader program.
	void CompileShader(const char* vertexCode, const char* fragmentCode);
	void CompileShader(const char* vertexCode, const char* geometryCode, const char* fragmentCode);
};

