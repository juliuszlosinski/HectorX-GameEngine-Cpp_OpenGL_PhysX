#include "Shader.h"

Shader::Shader()
{
	// Utworzenie pustego shadera.
	shaderID = 0;
}

// Konstrutkor.
Shader::Shader(const char* vertexLocation, const char* fragmentLocation)
{
	// Utworzenie shadera.
	CreateFromFiles(vertexLocation, fragmentLocation);
}

// Konstruktor.
Shader::Shader(const char* vertexLocation, const char* geometryLocation, const char* fragmentLocation)
{
	// Utworzenie shadera.
	CreateFromFiles(vertexLocation, geometryLocation, fragmentLocation);
}

// Zwroc lokalizacje uniformu.
GLuint Shader::GetUniformLocation(const GLchar* name)
{
	// Uzyskanie lokalizacji.
	return glGetUniformLocation(shaderID, name);
}

// Zalacz wartosc z uniformem macierza o okreslonej nazwie.
void Shader::AttachUniformMatrix4x4(const GLchar* name, glm::mat4 matrix)
{
	// Powiazanie wartosci z uniformem.
	glUniformMatrix4fv(GetUniformLocation(name), 1, GL_FALSE, glm::value_ptr(matrix));
}

// Zalacz wartosc z uniforme macierza o okreslonej lokalizacji.
void Shader::AttachUniformMatrix4x4(GLuint location, glm::mat4 matrix)
{
	// Powiazanie wartosci z uniformem.
	glUniformMatrix4fv(location, 1, GL_FALSE, glm::value_ptr(matrix));
}

// Powiazanie pojedynczej wartosci z uniformem o okreslonej nazwie.
void Shader::AttachUniformSingleFloatValue(const GLchar* name, float value)
{
	glUniform1f(GetUniformLocation(name), value);
}

// Powiazanie pojedynczej wartosci z uniformem o okreslonej lokalizacji.
void Shader::AttachUniformSingleFloatValue(GLuint location, float value)
{
	// Powiazanie wartosci.
	glUniform1f(location, value);
}

// Powiaz uniform kamery z kamera.
void Shader::AttachCamera(Camera* camera)
{
	// 1. Przeslanie pozycji.
	AttachUniformVector3("camera.position", camera->GetPosition());
	// 2. Przeslaniek kierunku.
	AttachUniformVector3("camera.direction", camera->GetDirection());
}

// Powiaz uniform z okreslona nazwa ze wektorem.
void Shader::AttachUniformVector3(const GLchar* name, glm::vec3 vector)
{
	// Powiazanie wartosci.
	glUniform3fv(GetUniformLocation(name), 1, glm::value_ptr(vector));
}

void Shader::AttachUniformVector3(GLuint location, glm::vec3 vector)
{
	// Powiazanie wartosci.
	glUniform3fv(location, 1, glm::value_ptr(vector));
}

// Powiaz tekstury uniform sampler o okreslonej nazwie z jednostka tekstury.
void Shader::BindTextureSamplerUniformToTextureUnit(const GLchar* name, GLuint id)
{
	// Powiazanie wartosci.
	glUniform1i(GetUniformLocation(name), id);
}

// Powiaz teskture uniform sampler o okreslonym polozeniu z jednostka tekstury.
void Shader::BindTextureSamplerUniformToTextureUnit(GLuint location, GLuint id)
{
	// Powiazanie wartosci.
	glUniform1i(location, id);
}


// Wyczyszczenie shadera.
void Shader::ClearShader()
{
	// 1. Usuwanie programu.
	if (shaderID != 0)
	{
		glDeleteProgram(shaderID);
	}
}

// Powiaz swiatlo kierunkowe z odpowiednim uniformem swiatla kierunkowego o okreslonej nazwie.
void Shader::AttachDirectionalLight(const GLchar* name, DirectionalLight* directionalLight)
{
	// 1. Zalaczenie koloru.
	std::string lightColour(name);
	lightColour.append(".lightColour");
	AttachUniformVector3(lightColour.c_str(), directionalLight->GetLightColour());

	// 2. Zalaczenie kierunku.
	std::string direction(name);
	direction.append(".direction");
	AttachUniformVector3(direction.c_str(), directionalLight->GetDirection());

	// 3. Zalaczenie mocy swiatla otoczenia.
	std::string aS(name);
	aS.append(".ambientStrength");
	AttachUniformSingleFloatValue(aS.c_str(), directionalLight->GetAmbientStrength());

	// 4. Zalaczenie mocy swiatla rozproszenia.
	std::string dS(name);
	dS.append(".diffuseStrength");
	AttachUniformSingleFloatValue(dS.c_str(), directionalLight->GetDiffuseStrength());

	// 5. Zalacznie macierzy transformacji.
	std::string lightSpaceMatrix(name);
	lightSpaceMatrix.append(".lightSpaceMatrix");
	AttachUniformMatrix4x4(lightSpaceMatrix.c_str(), directionalLight->GetLigthSpaceMatrix());
}

// Powiaz swiatlo punktowe z odpowiednim uniformem o okreslonej nazwie.
void Shader::AttachPointLight(const GLchar* name, PointLight* pointLight)
{
	// 1. Zalaczenie koloru.
	std::string lightColour(name);
	lightColour.append(".lightColour");
	AttachUniformVector3(lightColour.c_str(), pointLight->GetLightColour());

	// 2. Zalaczenie pozycji.
	std::string lightPosition(name);
	lightPosition.append(".position");
	AttachUniformVector3(lightPosition.c_str(), pointLight->GetPosition());

	// 3. Zalaczenie mocy swiatla otoczenia.
	std::string aS(name);
	aS.append(".ambientStrength");
	AttachUniformSingleFloatValue(aS.c_str(), pointLight->GetAmbientStrength());

	// 4. Zalaczenie mocy swiatla rozproszenia.
	std::string dS(name);
	dS.append(".diffuseStrength");
	AttachUniformSingleFloatValue(dS.c_str(), pointLight->GetDiffuseStrength());

	// 5. Zalaczenie wspolczynnika stalego.
	std::string c(name);
	c.append(".constant");
	AttachUniformSingleFloatValue(c.c_str(), pointLight->GetConstant());

	// 6. Zalaczenie wspolczynnika liniowego.
	std::string l(name);
	l.append(".linear");
	AttachUniformSingleFloatValue(l.c_str(), pointLight->GetLinear());

	// 7. Zalaczenie wspolczynnika kwadratowego.
	std::string q(name);
	q.append(".quadratic");
	AttachUniformSingleFloatValue(q.c_str(), pointLight->GetQuadratic());
}

// Powiaz swiatlo reflektorowe z odpowiednim uniformem o okreslonej nazwie
void Shader::AttachSpotLight(const GLchar* name, SpotLight* spotLight)
{
	// 1. Zalaczenie koloru.
	std::string lightColour(name);
	lightColour.append(".lightColour");
	AttachUniformVector3(lightColour.c_str(), spotLight->GetLightColour());

	// 2. Zalaczenie pozycji.
	std::string lightPosition(name);
	lightPosition.append(".position");
	AttachUniformVector3(lightPosition.c_str(), spotLight->GetPosition());

	// 3. Zalaczenie mocy swiatla otoczenia.
	std::string aS(name);
	aS.append(".ambientStrength");
	AttachUniformSingleFloatValue(aS.c_str(), spotLight->GetAmbientStrength());

	// 4. Zalaczenie mocy swiatla rozproszenia.
	std::string dS(name);
	dS.append(".diffuseStrength");
	AttachUniformSingleFloatValue(dS.c_str(), spotLight->GetDiffuseStrength());

	// 5. Zalaczenie wspolczynnika stalego.
	std::string c(name);
	c.append(".constant");
	AttachUniformSingleFloatValue(c.c_str(), spotLight->GetConstant());

	// 6. Zalaczenie wspolczynnika liniowego.
	std::string l(name);
	l.append(".linear");
	AttachUniformSingleFloatValue(l.c_str(), spotLight->GetLinear());

	// 7. Zalaczenie wspolczynnika kwadratowego.
	std::string q(name);
	q.append(".quadratic");
	AttachUniformSingleFloatValue(q.c_str(), spotLight->GetQuadratic());

	// 8. Zalaczenie kierunku padanie swiatla.
	std::string direction(name);
	direction.append(".direction");
	AttachUniformVector3(direction.c_str(), spotLight->GetDirection());

	// 9. Zalacznie kata odciecia.
	std::string angle(name);
	angle.append(".cutOffAngle");
	AttachUniformSingleFloatValue(angle.c_str(), spotLight->GetCutOffAngle());
}

// Powiazanie materialu z uniformem o okreslonej nazwie.
void Shader::AttachMaterial(const GLchar* name, Material* material)
{
	// 1. Zalaczenie jasnosci.
	std::string shininess(name);
	shininess.append(".shininess");
	AttachUniformSingleFloatValue(shininess.c_str(), material->GetShininess());
}

// Uzywanie shadera.
void Shader::UseShader()
{
	// 1. Uzywanie programu z shaderami.
	glUseProgram(shaderID);
}

// Zwrocenie zawartosci pliku do lancucha znakow.
std::string Shader::ReadFile(const char* fileLocation)
{
	// 1. Lancuch znakow.
	std::string content;

	// 2. Obiekt do wczytywania pliku.
	std::ifstream fileStream(fileLocation, std::ios::in);

	// 3. Sprawdzenie czy plik zostal otworzony.
	if (!fileStream.is_open())
	{
		printf("Failed to read%s! File doesn't exist.", fileLocation);
		return "";
	}

	// 4. Sprawdzenie czy nie dotarislmy do konca pliku oraz dodanie do kontentu.
	std::string line = "";
	while (!fileStream.eof())
	{
		std::getline(fileStream, line);
		content.append(line + "\n");
	}

	// 5. Zamkniecie pliku.
	fileStream.close();

	// 6. Zwrocenie ciagu otrzymanego ciagu znakow.
	return content;
}

// Utworzenie shadera z dwoch plikow.
void Shader::CreateFromFiles(const char* vertexLocation, const char* fragmentLocation)
{
	// 1. Czytanie pliku z Vertex Shader oraz zapisanie go w lancuchu znakow.
	std::string vertexString = ReadFile(vertexLocation);
	const char* vertexCode = vertexString.c_str();

	// 2. Czytanie pliku z Fragment Shader oraz zapisanie go w lancuchu znakow.
	std::string fragmentString = ReadFile(fragmentLocation);
	const char* fragmentCode = fragmentString.c_str();

	// 3. Kompilacja shadera ~ uzyskanie gotowego shadera do uzycia.
	CompileShader(vertexCode, fragmentCode);
}

// Utworzenie shadera z trzech plikow.
void Shader::CreateFromFiles(const char* vertexLocation, const char* geometryLocation, const char* fragmentLocation)
{
	// 1. Czytanie pliku z Vertex Shader oraz zapisanie go w lancuchu znakow.
	std::string vertexString = ReadFile(vertexLocation);
	const char* vertexCode = vertexString.c_str();

	// 2. Czytanie pliku z Geometry Shader oraz zapisanie go w lancuchu znakow.
	std::string geometryString = ReadFile(geometryLocation);
	const char* geometryCode = geometryString.c_str();

	// 2. Czytanie pliku z Fragment Shader oraz zapisanie go w lancuchu znakow.
	std::string fragmentString = ReadFile(fragmentLocation);
	const char* fragmentCode = fragmentString.c_str();

	// 3. Kompilacja shadera ~ uzyskanie gotowego shadera do uzycia.
	CompileShader(vertexCode, geometryCode, fragmentCode);
}

// Dodaj shader do programu.
void Shader::AddShader(GLuint program, const char* shaderCode, GLenum shaderType)
{
	// 1. Utworzenie pustego shadera o okreslonym typie.	-> UTWORZENIE
	GLuint theShader = glCreateShader(shaderType);

	// 2. Przypisanie kodu.
	const GLchar* theCode[1];
	theCode[0] = shaderCode;

	GLint codeLength[1];
	codeLength[0] = strlen(shaderCode);

	// 3. Zalaczenie kodu zrodlowego do pustego shadera.	-> ZALACZENIE_KODU
	glShaderSource(theShader, 1, theCode, codeLength);

	// 4. Kompilacja shadera.			-> KOMPILACJA
	glCompileShader(theShader);

	// 5. Sprawdzanie bledow.
	GLint result = 0;
	GLchar eLog[1024] = { 0 };
	glGetShaderiv(theShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(theShader, sizeof(eLog), NULL, eLog);
		printf("Error compiling the %d shader: '%s' \n", shaderType, eLog);
		return;
	}

	// 6. Zalaczenie shadera do programu.		-> ZALACZENIE DO PROGRAMU
	glAttachShader(program, theShader);
}

// Kompiluj shader.
void Shader::CompileShader(const char* vertexCode, const char* fragmentCode)
{
	// 1. Utworzenie pustego programu.
	shaderID = glCreateProgram();

	if (!shaderID)
	{
		printf("Error creating shader program!\n");
		return;
	}

	// 2. Dodanie Vertex Shader do programu.
	AddShader(shaderID, vertexCode, GL_VERTEX_SHADER);

	// 3. Dodanie Fragment Shader do programu.
	AddShader(shaderID, fragmentCode, GL_FRAGMENT_SHADER);

	// 4. Powiazanie ze soba wszystkich shaderow oraz stworzenie z nich pliku wykonalnego dla karty graficznej (poniewaz programy sa na karcie graficznej a my tylko zmieniamy jego tresc).
	glLinkProgram(shaderID);
}

// Kompiluj shader.
void Shader::CompileShader(const char* vertexCode, const char* geometryCode, const char* fragmentCode)
{
	// 1. Utworzenie pustego programu.
	shaderID = glCreateProgram();

	if (!shaderID)
	{
		printf("Error creating shader program!\n");
		return;
	}

	// 2. Dodanie Vertex Shader do programu.
	AddShader(shaderID, vertexCode, GL_VERTEX_SHADER);

	// 3. Dodanie Geometrycznego Shader'a do programu.
	AddShader(shaderID, geometryCode, GL_GEOMETRY_SHADER);

	// 4. Dodanie Fragment Shader do programu.
	AddShader(shaderID, fragmentCode, GL_FRAGMENT_SHADER);

	// 4. Powiazanie ze soba wszystkich shaderow oraz stworzenie z nich pliku wykonalnego dla karty graficznej (poniewaz programy sa na karcie graficznej a my tylko zmieniamy jego tresc).
	glLinkProgram(shaderID);
}

// Wylacz shader.
void Shader::EndUsing()
{
	// Zakoncz uzywanie.
	glUseProgram(0);
}

// Destruktor
Shader::~Shader()
{
	// 1. Usuwanie programu.
	if (shaderID != 0)
	{
		glDeleteProgram(shaderID);
	}
}