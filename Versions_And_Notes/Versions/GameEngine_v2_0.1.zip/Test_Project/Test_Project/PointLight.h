#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>


class PointLight
{
public:
    PointLight();

    PointLight(float red, float green, float blue,
        float ambientStrength, float diffuseStrength,
        float quadratic, float linear, float constant,
        float xPos, float yPos, float zPos);

    // Zwroc kolor swiatla.
    glm::vec3 GetLightColour();

    // Ustaw kolor swiatla.
    void SetLightColour(float red, float green, float blue);

    // Zwroc pozycje zrodla swiatla.
    glm::vec3 GetPosition();

    // Ustaw pozycje swiatla.
    void SetPosition(float x, float y, float z);

    // Zwroc moc swiatla otoczenia.
    float GetAmbientStrength();

    // Ustaw moc oswietlenia otoczenia.
    void SetAmbientStrength(float ambientStrength);

    // Zwroc moc swiatla rozproszenia.
    float GetDiffuseStrength();

    // Ustaw moc swiatla otoczenia.
    void SetDiffuseStrength(float diffuseStrength);

    // Zwroc staly parametr.
    float GetConstant();

    // Ustaw staly parametr.
    void SetConstant(float constant);

    // Zwroc liniowy parametr.
    float GetLinear();

    // Ustaw liniowy parametr.
    void SetLinear(float linear);

    // Zwroc kwadratowy parametr.
    float GetQuadratic();

    // Ustaw kwadratowy parametr.
    void SetQuadratic(float quadratic);

    // Destruktor.
    ~PointLight();

private:
    glm::vec3 lightColour;       // Kolor swiatla.
    glm::vec3 position;          // Pozycja swiatla. 

    float ambientStrength;  // Sila swiatla otoczenia.
    float diffuseStrength;  // Sila swiatla rozproszenia.

    // 
    //                                               1
    //  f(distance) =  ---------------------------------------------------------
    //                  quadratic * distance^2 + linear * distance + constant

    float constant;         // Staly wspolczynnik.
    float linear;           // Liniowy wspolczynnik.
    float quadratic;        // Kwadrotwy wspolczynnik.
};

