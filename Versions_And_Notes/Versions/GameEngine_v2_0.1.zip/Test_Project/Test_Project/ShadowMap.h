#pragma once

#include <GL/glew.h>
#include <cstdio>

class ShadowMap
{
public:
	// Konstruktor.
	ShadowMap();

	// Konstruktor + Inicjalizacja.
	ShadowMap(GLuint shadowWidth, GLuint shadowHeight);

	// Ustawienie wczytywania.
	void BindBuffer_Write();

	// Tworzenie oraz inicjalizacja bufora ramki wraz z mapa cieni.
	bool CreateFrameBufferAndTexture(GLuint shadowWidth, GLuint shadowHeight);

	// Uzyskaj idyntyfikator bufora ramki.
	GLuint GetFBOID();

	// Uzyskaj identyfikator tekstury.
	GLuint GetTextureShadowMapID();

	// Uzyskaj dlugosc mapy cienia.
	GLuint GetShadowWidth();

	// Uzyskaj wysokosc mapy cienia.
	GLuint GetShadowHeight();

	// Skoncz wpisywanie.
	void EndUsing();

	// Destruktor.
	~ShadowMap();

private:
	GLuint FBO;					// Identyfikator bufora ramki.
	GLuint textureShadowMapID;	// Identyfikator tekstury z mapa cieni.

	GLuint shadowWidth;			// Dlugosc mapy cieni.
	GLuint shadowHeight;		// Wysokosc mapy cieni.
};

