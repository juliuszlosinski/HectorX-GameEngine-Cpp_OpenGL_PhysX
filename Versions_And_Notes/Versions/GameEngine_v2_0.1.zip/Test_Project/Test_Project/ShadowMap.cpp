#include "ShadowMap.h"

// Konstruktor.
ShadowMap::ShadowMap()
{
	// 1. Inicjalizacja identyfikatora bufora ramki.
	FBO = 0;

	// 2. Inicjalizacja identyfikator tesktury z mapa cieni.
	textureShadowMapID = 0;
}

// Konstruktor + Inicjalizacja.
ShadowMap::ShadowMap(GLuint shadowWidth, GLuint shadowHeight)
{
	CreateFrameBufferAndTexture(shadowWidth, shadowHeight);
}

// Ustawienie wczytywania.
void ShadowMap::BindBuffer_Write()
{
	// 1. Ustawienie bufora do, ktorego bedzie rysowane.
	glBindFramebuffer(GL_FRAMEBUFFER, FBO);
}

// Skoncz wpisywanie.
void ShadowMap::EndUsing()
{
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

// Tworzenie oraz inicjalizacja bufora ramki wraz z mapa cieni.
bool ShadowMap::CreateFrameBufferAndTexture(GLuint shadowWidth, GLuint shadowHeight)
{
	// 1. Ustawianie parametrow.
	this->shadowWidth = shadowWidth;
	this->shadowHeight = shadowWidth;

	// 2. Generowanie bufora ramki.
	glGenFramebuffers(1, &FBO);

	// 3. Utworzenie tekstury.
	glGenTextures(1, &textureShadowMapID);

	// 4. Ustawienie tekstury jako roboczej.
	glBindTexture(GL_TEXTURE_2D, textureShadowMapID);

	// 5. Ustawienie pustej tekstury ~ uzyskiwanie wartosci glebokosci od 0.0 do 1.0 bazujc na znormalizowanych kordynatach.
	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, shadowWidth, shadowHeight, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);

	// 6. Owijanie tekstury (jest ustawiane powtarzanie).
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
	float bColour[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, bColour);

	// 7. Ustawianie filtrow (jak ma sie zachowywac tekstura w kontekscie odleglosci).
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// 8. Ustawienie bufora ramki roboczej.
	glBindFramebuffer(GL_FRAMEBUFFER, FBO);

	// 9. Polaczenie tekstury z buforem ramki.
	// Kiedy scena bedzie renderowana, to zostanie ona do tej tekstury.
	// GL_DEPTH_ATTACHMENT ~ Wartosci glebi beda wpisywane do tekstury po wyrenderowaniu sceny.
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, textureShadowMapID, 0);

	// 10. Nie odczytujemy wartosci koloru z za��cznika kolor�w.
	glDrawBuffer(GL_NONE);

	// 11. Nie zapisujemy wartosci koloru z za��cznika kolor�w.
	glReadBuffer(GL_NONE);

	// 12. Sprawdzanie czy wszystko si� powiod�o.
	GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);

	if (status != GL_FRAMEBUFFER_COMPLETE)
	{
		// 12.1 Nie powiodlo sie!
		printf("Framebuffer Error: %i\n", status);
		return false;
	}

	// 13. Zdjecie roboczego bufora ramki, ustawienie na tego glownego ze scena.
	// 0 ~ To jest na, kt�rmy rysujemy i b�dzie on zamieniony kiedy wywolamy SwapBuffers().
	glBindFramebuffer(GL_FRAMEBUFFER, 0);

	// 14. Powiodlo sie!
	return true;
}

// Uzyskaj idyntyfikator bufora ramki.
GLuint ShadowMap::GetFBOID()
{
	return FBO;
}

// Uzyskaj identyfikator tekstury.
GLuint ShadowMap::GetTextureShadowMapID()
{
	return textureShadowMapID;
}

// Uzyskaj dlugosc mapy cienia.
GLuint ShadowMap::GetShadowWidth()
{
	return shadowWidth;
}

// Uzyskaj wysokosc mapy cienia.
GLuint ShadowMap::GetShadowHeight()
{
	return shadowHeight;
}

// Destrutkor.
ShadowMap::~ShadowMap()
{
	if (FBO)
	{
		glDeleteFramebuffers(1, &FBO);
	}

	if (textureShadowMapID)
	{
		glDeleteTextures(1, &textureShadowMapID);
	}
}