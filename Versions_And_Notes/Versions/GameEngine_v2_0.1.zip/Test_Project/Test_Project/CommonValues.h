#ifndef COMMONVALS
#define COMMONVALS

// Zaladowanie pliku do ladowania tekstur/ obrazkow.
#include "stb_image.h"

#endif 