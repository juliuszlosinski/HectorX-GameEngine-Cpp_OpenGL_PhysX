#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>


class SpotLight
{
public:
    SpotLight();

    SpotLight(float red, float green, float blue,
        float ambientStrength, float diffuseStrength,
        float quadratic, float linear, float constant, float cutOffAngle,
        float xPos, float yPos, float zPos,
        float xDirection, float yDirection, float zDirection);

    // Zwroc kolor swiatla.
    glm::vec3 GetLightColour();

    // Ustaw kolor swiatla.
    void SetLightColour(float red, float green, float blue);

    // Zwroc pozycje zrodla swiatla.
    glm::vec3 GetPosition();

    /// Ustawienie swiatla.
    void SetFlash(glm::vec3 pos, glm::vec3 dir)
    {
        this->position = pos;
        this->direction = dir;
    }

    // Ustaw pozycje swiatla.
    void SetPosition(float x, float y, float z);

    // Zwroc moc swiatla otoczenia.
    float GetAmbientStrength();

    // Ustaw moc oswietlenia otoczenia.
    void SetAmbientStrength(float ambientStrength);

    // Zwroc moc swiatla rozproszenia.
    float GetDiffuseStrength();

    // Ustaw moc swiatla otoczenia.
    void SetDiffuseStrength(float diffuseStrength);

    // Zwroc staly parametr.
    float GetConstant();

    // Ustaw staly parametr.
    void SetConstant(float constant);

    // Zwroc liniowy parametr.
    float GetLinear();

    // Ustaw liniowy parametr.
    void SetLinear(float linear);

    // Zwroc kwadratowy parametr.
    float GetQuadratic();

    // Ustaw kwadratowy parametr.
    void SetQuadratic(float quadratic);

    // Zwroc kierunek patrzenia.
    glm::vec3 GetDirection();

    // Ustaw kierunek patrzenia.
    void SetDirection(float xDir, float yDir, float zDir);

    // Zwroc kat odciecia.
    float GetCutOffAngle();

    // Ustaw kat odciecia.
    void SetCutOffAngle(float cutOffAngle);

    // Destruktor.
    ~SpotLight();
private:
    glm::vec3 lightColour;  // Kolor swiatla.
    glm::vec3 position;     // Pozycja swiatla.

    float ambientStrength;  // Sila swiatla otoczenia.
    float diffuseStrength;  // Sila swiatla rozproszenia.

    float constant;         // Stala.
    float linear;           // Liniowy wspolczynnik.
    float quadratic;        // Kwadratowy wspolczynnik.

    // +
    glm::vec3 direction;    // Kierunek swiatla.
    float cutOffAngle;      // Kat odciecia.
};

