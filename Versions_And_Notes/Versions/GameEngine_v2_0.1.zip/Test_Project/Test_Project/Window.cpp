#include "Window.h"

Window::Window()
{
	// 1. Ustawiane parametr�w okna.

	// 1.1 Dlugosc.
	windowWidth = 800;

	// 1.2 Wysokosc.
	windowHeight = 600;

	// 1.3 Tytul.
	title =  "SpikeEngine";

	// 2. Ustawienie klawiszy.
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
	
	// * Inicjalizacja reszty parametrow.
	bufferHeight = 0;
	bufferWidth = 0;
	lastX = 0;
	lastY = 0;
	xChange = 0;
	yChange = 0;
	mousedFirstMoved = false;

}

Window::Window(GLuint width, GLuint height, const char* title)
{
	// 1. Ustawienie parametrow okna.

	// 1.1 Dlugosc.
	this->windowWidth = width;

	// 1.2 Wysokosc.
	this->windowHeight = height;

	// 1.3 Tytul.
	this->title = title;

	// 2. Ustawienie klawiszy.
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}

	// * Inicjalizacja reszty parametrow.
	bufferHeight = 0;
	bufferWidth = 0;
	lastX = 0;
	lastY = 0;
	xChange = 0;
	yChange = 0;
	mousedFirstMoved = false;
}

// Ustawienie wielkosci portu ogladacza.
void Window::SetViewPort(int x, int y, int width, int height)
{
	glViewport(x, y, width, height);
}

int Window:: Initialize()
{
	// 1. Inicjalizacja API GLFW.
	if (!glfwInit())
	{
		printf("GLFW initialization failed!");

		glfwTerminate();

		return 1;
	}

	// 2. Ustawianie parametr�w okna.

	// 2.0 Ilosc probek.
	glfwWindowHint(GLFW_SAMPLES, 4);

	// 2.1 Wersja na kt�rej pracuje.
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

	// 2.2 Ustawienie z wczesniejszymi wersjami.
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// 2.3 Ustawienie kompatybilno�ci z nowszymi wersjami.
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	// 3. Utworzenie okna.
	window = glfwCreateWindow(windowWidth, windowHeight, title, nullptr, nullptr);

	// 3.1 Sprawdzenie czy utworzenie okna powiodlo sie.
	if (!window)
	{
		// 3.1.1 Wypisanie komunikatu o niepowodzeniu.
		printf("GLFW window creation failed!");

		// 3.1.2 Zwrocenie zainijcalizowanych zasobow.
		glfwTerminate();

		// 3.1.2 Wyjscie z programu.
		return 1;
	}

	// 4. Uzyskanie informacja na temat wysokosc oraz dlugosci bufora ramki.
	glfwGetFramebufferSize(window, &bufferWidth, &bufferHeight);

	// 5. Ustawienie kontekstu oraz okna, zebymsy mogli uzywac GLEW oraz OpenGL. Zwiazanie kontekstu z oknem.
	glfwMakeContextCurrent(window);

	// 6. Ustawienie pozwolenia na uzywanie nowoczesnych rozszerzen.
	glewExperimental = GL_TRUE;

	// 7. Inicjalizacja API GLEW (biblioteki oraz wszystkie funkcje jakie tam sa).
	if (glewInit() != GLEW_OK)
	{
		// 7.1 Wypisanie komunikatu o niepowodzeniu.
		printf("GLEW initialization failed!");

		// 7.2 Zniszczenie wczesniej utworzengo okna.
		glfwDestroyWindow(window);

		// 7.3 Zwrocenie zasobow.
		glfwTerminate();

		// 7.4 Powrot z programu.
		return 1;
	}

	// 8. Aktywowanie bufora glebokosc, zeby moc pozniej mowic, ktore sciany sa dalej.
	glEnable(GL_DEPTH_TEST);

	// 9. Ustawienie rozmiaru portu widoku (view port).
	glViewport(0, 0, bufferWidth, bufferHeight);

	// 10. Ustawienie oddzwonien na zdarzenia.
	CreateCallBacks();

	// 11. Ustawienie uzytkownika dla okna.
	glfwSetWindowUserPointer(window, this);

	// 12. Aktywowanie wielo probek.
	glEnable(GL_MULTISAMPLE);
}

void Window::ClearBuffer()
{
	// 1. Czysczenie ekranu.
	glClearColor(0.0f, 0.0f, 0.75f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void Window::SwapBuffers()
{
	// 1. Zamiana buforow.
	glfwSwapBuffers(window);
}

void Window::CreateCallBacks()
{
	glfwSetKeyCallback(window, handleKeys);
	glfwSetCursorPosCallback(window, handleMouse);
}

bool* Window::GetKeys()
{
	return keys;
}

void Window::handleKeys(GLFWwindow* window, int key, int code, int action, int mode) // Obs�uga klawiszy ~ Na tym bedzie call back od GLFW.
{
	// 1. Uzyskanie okna.
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	// 2. Zamknij okno jezeli uzytkownik nacisnal escape.
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}

	// 3. Sprawdzenie czy jakies klawisz zostal nacisniety.
	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
		}
		else if(action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
		}
	}
}

void Window::handleMouse(GLFWwindow* window, double xPos, double yPos)
{
	// 1. Uzyskanie okna.
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));
	
	// 2. Sprawdzenie czy jest pierwsze poruszanie myszka.
	if (theWindow->mousedFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mousedFirstMoved = false;
	}

	// 3. Uzyskanie roznic.
	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	// 4. Ustawienie ostatniej pozycji x.
	theWindow->lastX = xPos;
	
	// 5. Ustawienie ostatniej pozycji y.
	theWindow->lastY = yPos;

	//printf("x: %.6f, y: %.6f\n", theWindow->xChange, theWindow->yChange);
}

Window::~Window()
{
	// 1. Zniszeczenie okna.
	glfwDestroyWindow(window);

	// 2. Zwrocenie zasobow prze GLFW.
	glfwTerminate();
}

int Window::ShouldClose()
{
	// 1. Zwrocenie czy okno powinno sie zamknac.
	return glfwWindowShouldClose(window);
}

void Window::PollEvents()
{
	// 1. Oczekuj na zdarzenia.
	glfwPollEvents();
}

int Window::GetBufferWidth()
{
	return bufferWidth;
}

int Window::GetBufferHeight()
{
	return bufferHeight;
}

GLuint Window::GetWindowWidth()
{
	return windowWidth;
}

GLuint Window::GetWindowHeight()
{
	return windowHeight;
}

GLfloat Window::GetXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::GetYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}

const char* Window::GetTitle()
{
	return title;
}

bool Window::IsKeyPressed(int keyCode)
{
	return keys[keyCode];
}

bool Window::IsKeyReleased(int keyCode)
{
	return !keys[keyCode];
}
