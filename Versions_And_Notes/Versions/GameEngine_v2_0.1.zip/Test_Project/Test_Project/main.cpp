#define STB_IMAGE_IMPLEMENTATION

#include "CommonValues.h"
#include <stdio.h>

// Za��czenie pliku nag��wkowego z �a�cuchami znak�w.
#include <string.h>

// Za��czenie pliku nag��wkowego z GLEW.
#include <GL/glew.h>

/// Za��czenie pliku nag��wkowego z GLFW.
#include <GLFW/glfw3.h>

#include "Shader.h"
#include "Texture.h"

#include "Window.h"
#include "Mesh.h"
#include "Camera.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "Material.h"
#include "ShadowMap.h"
#include "FrameShooter.h"
#include "Skybox.h"

Texture machineTexture;
Texture plainTexture;

Shader mainShader;
Shader simpleShader;
Shader dlShader;
Shader testShader;
Shader fotoShader;

Mesh floorMesh;
Mesh pyramidMesh;

Camera mainCamera;
glm::mat4 projectionMatrix;

Window window;

DirectionalLight mainLight;
PointLight pointLight;
SpotLight spotLight;

Material shinyMaterial;

unsigned int FBO, texColourBuffer;

Mesh plain;

FrameShooter shooter;

Skybox skybox;

void CreateObjects()
{
	// WINDOW
	window = Window();
	window.Initialize();

	// MESHES:
	unsigned int indices[] = {
		0, 3, 1, // Jedna strona piramidy.
		1, 3, 2, // Drugo strona piramidy.
		2, 3, 0, // Frontalna strona piramidy.
		0, 1, 2  // Podstawa piramidy.
	};

	GLfloat vertices[] = {
		//   x      y      z		  u	   v		 nx    ny    nz
			-1.0f, -1.0f, -0.6f,	0.0f, 0.0f,		0.0f, 0.0f,	0.0f,
			0.0f, -1.0f, 1.0f,		0.5f, 0.0f,		0.0f, 0.0f, 0.0f,
			1.0f, -1.0f, -0.6f,		1.0f, 0.0f,		0.0f, 0.0f,	0.0f,
			0.0f, 1.0f, 0.0f,		0.5f, 1.0f,		0.0f, 0.0f, 0.0f,
	};
	Mesh::CalcAverageNormals(indices, 12, vertices, 32, 8, 5);
	pyramidMesh = Mesh();
	pyramidMesh.CreateMesh(vertices, 32, indices, 12);

	// ------------]

	GLfloat floor_vertices[] =
	{
		//  x	  y		z			  u    v		 nx      ny     nz
		-10.0f, 0.0f, -10.0f,	0.0f, 0.0f,			0.0f, -1.0f, 0.0f,
		10.0f, 0.0f, -10.0f,	10.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		-10.0f, 0.0f, 10.0f,	0.0f, 10.0f,		0.0f, -1.0f, 0.0f,
		10.0f, 0.0f, 10.0f,		10.0f, 10.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int floor_indices[]
	{
		0, 2, 1,
		1, 2, 3
	};

	GLfloat plainVertices[] =
	{
		//  x	  y		z			  u    v		 nx      ny     nz
		-1.0f, -1.0f, 0.0f,		0.0f, 0.0f,			0.0f, 0.0f, 0.0f,
		1.0f, -1.0f, 0.0f,		1.0f, 0.0f,			0.0f, 0.0f, 0.0f,
		1.0f, 1.0f, 0.0f,		1.0f, 1.0f,			0.0f, 0.0f, 0.0f,
		-1.0f, 1.0f, 0.0f,		0.0f, 1.0f,			0.0f, 0.0f, 0.0f,
	};


	unsigned int plainIndices[]
	{
		0, 1, 2,
		2, 3, 0,
	};

	plain = Mesh();
	plain.CreateMesh(plainVertices, 32, plainIndices, 6);

	floorMesh = Mesh();
	floorMesh.CreateMesh(floor_vertices, 32, floor_indices, 6);

	// SHADERS:
	mainShader = Shader();
	mainShader.CreateFromFiles("Shaders/vertexShader.vt", "Shaders/fragmentShader.frag");

	simpleShader = Shader();
	simpleShader.CreateFromFiles("Shaders/simpleV.vt", "Shaders/simpleF.frag");

	testShader = Shader();
	testShader.CreateFromFiles("Shaders/test.vt", "Shaders/test.frag");

	dlShader = Shader();
	dlShader.CreateFromFiles("Shaders/directionalShadowMapVertex.vt", "Shaders/directionalShadowMapFrag.frag");

	fotoShader = Shader();
	fotoShader.CreateFromFiles("Shaders/foto.vt", "Shaders/foto.frag");

	// TEXTURES:
	machineTexture = Texture();
	machineTexture.LoadTextureA("Textures/machine.png");

	plainTexture = Texture();
	plainTexture.LoadTextureA("Textures/grass.png");

	// CAMERA:
	mainCamera = Camera(glm::vec3(0.0f, 3.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f), 0.0f, -90.0f, 5.0f, 0.5f);

	// MATRICES:
	projectionMatrix = glm::perspective(glm::radians(45.0f), (float)window.GetBufferWidth() / (float)window.GetWindowHeight(), 0.1f, 100.0f);

	// SWIATLO:
	mainLight = DirectionalLight(1.0f, 1.0f, 1.0f, // R, G, B
									0.3f, 0.5f, // ambient , diffuse 
		1.5f, -3.0f, -1.0f); // xD, yD, zD
	pointLight = PointLight(1.0f, 0.0f, 0.0f, 
							0.5f, 0.25f, 
					0.032f, 0.09f, 1.0f,
					1.0f, 1.0f, -1.0f); // POS

	spotLight = SpotLight(0.0f, 1.0f, 0.0f, 
					1.0f, 1.0f,
					0.032f, 0.09f, 1.0f,
					0.95f, // ANGLE
					1.0f, 1.0f, -1.0f,	// POS
					0.0f, 0.0f, -2.0f);	// DIR

	// MATERIALY:
	shinyMaterial = Material(32);


	// ZDJECIA RAMEK:
	shooter = FrameShooter(800, 600);
	shooter.Initialize();

	// SKYBOX:
	skybox = Skybox();
	std::vector<std::string> skyboxFaces;
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_rt.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_lf.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_up.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_dn.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_bk.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_ft.tga");
	skybox.LoadSkybox(skyboxFaces);

}

void TestFotoShader();
void TestShadowMap();
GLuint DirectionalLight_Generate_Shadow_Map();

float delta = 0;

// RENDEROWANIE SCENY:
void RenderScene(Shader& shader)
{
	shader.BindTextureSamplerUniformToTextureUnit("mainTexture", 0);

	//delta += 0.01f;
	glm::mat4 modelMatrix(1.0f);
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, 2.75f, -4.0f));
	modelMatrix = glm::scale(modelMatrix, glm::vec3(1.25f, 1.25f, 1.25f));
	shader.AttachUniformMatrix4x4("model", modelMatrix);
	machineTexture.UseTexture(0);
	pyramidMesh.RenderMesh();

	modelMatrix = glm::mat4(1.0f);
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, 0.0f, -5.0f));
	shader.AttachUniformMatrix4x4("model", modelMatrix);
	plainTexture.UseTexture(0);
	floorMesh.RenderMesh();
}

// GLOWNE RENDEROWANIE:
void MainRender(Shader& shader)
{
	// 0. Uzyskanie identyfikatora mapy cieni.
	GLuint id = DirectionalLight_Generate_Shadow_Map();

	// 1. Ustawienie rozmiaru portu ogladacza.
	glViewport(0, 0, 800, 600);

	window.ClearBuffer();

	skybox.Render(mainCamera.GetViewMatrix(), projectionMatrix);

	// 2. Uzywanie glownego shadera.
	shader.UseShader();

	// 3. Zalacznie uniformow.

		// 3.1 Swiatel.
		shader.AttachDirectionalLight("directionalLight", &mainLight);
		shader.AttachPointLight("pointLight", &pointLight);
		//shader.AttachSpotLight("spotLight", &spotLight);

		// 3.1 Kamery.
		shader.AttachCamera(&mainCamera);

		// 3.2 Materialow.
		shader.AttachMaterial("material", &shinyMaterial);

		// 3.3 Macierze.
		shader.AttachUniformMatrix4x4("lightSpaceMatrix", mainLight.GetLigthSpaceMatrix());

		// 3.3.1 Projekcji.
		shader.AttachUniformMatrix4x4("projection", projectionMatrix);;

		// 3.3.2 Widoku.
		shader.AttachUniformMatrix4x4("view", mainCamera.GetViewMatrix());

		// 3.4 Zalaczenie mapy cieni swiatla jednokierunkowego.
		shader.BindTextureSamplerUniformToTextureUnit("directionalShadowMap", 1);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, id);
		glDepthMask(GL_TRUE);
	// 4. Renderowanie sceny.
	RenderScene(shader);

	// 5. Zakonczenie renderowania.
	shader.EndUsing();
}

void TestFotoShader()
{
	// TESTOWANIE WYKONYWANIA ZDJEC ORAZ ICH OBRABIANIA.

	// 1. Uzyskanie zdjecia ramki.
	GLuint id = shooter.GetFrameShoot(mainShader, MainRender);

	// 2. Uzywanie shadera.
	fotoShader.UseShader();

	// 3. Zalacznie tekstury z okreslona jednostka tekstury.
	fotoShader.BindTextureSamplerUniformToTextureUnit("screenTexture", 3);

	// 4. Powiazanie jednostki tekstury nr.3 z okreslan� tekstur�
	glActiveTexture(GL_TEXTURE3);
	glBindTexture(GL_TEXTURE_2D, id);
	
	// 5. Renderowanie obiektu.
	plain.RenderMesh();

	// 6. Koniec uzywania shadera.
	fotoShader.EndUsing();
}

GLuint DirectionalLight_Generate_Shadow_Map()
{
	// 1. Utworzenie bufora ramki oraz bufor kolorow (tekstury).
	mainLight.GetDirectionalShadowMap()->BindBuffer_Write();

	// 2. Ustawienie rozmiaru portu ogladacza.
	glViewport(0, 0, 1024, 1024);

	// 3. Wyczyszcynie bufora glebi.
	glClear(GL_DEPTH_BUFFER_BIT);

	// 4. Uzywanie shadera.
	dlShader.UseShader();

	// 5. Przeslanie uniformu do shadera.
	dlShader.AttachUniformMatrix4x4("lightSpaceMatrix", mainLight.GetLigthSpaceMatrix());

	// 6. Renderowanie sceny.
	RenderScene(dlShader);

	// 7. Skonczenie uzywania shadera.
	dlShader.EndUsing();

	// 8. Skonczenie uzywanie bufora ramki.
	mainLight.GetDirectionalShadowMap()->EndUsing();

	// 9. Zwrocenie identyfikator mapy cieni/ tekstury.
	return mainLight.GetDirectionalShadowMap()->GetTextureShadowMapID();
}

void TestShadowMap()
{
	// 1. Uzyksanie identyfikatora mapy cieni.
	GLuint id = DirectionalLight_Generate_Shadow_Map();

	// 2. Uzywanie shadera do testowania mapy cieni.
	testShader.UseShader();

	// 3. Przypisanie probkera do jednostki tekstury o numerze 1.
	testShader.BindTextureSamplerUniformToTextureUnit("mainTexture", 1);

	// 4. Zalaczenie tekstury o wczesniej uzyskanym identyfikatorze mapy cieni  do jednostki tekstury.
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, id);

	// 5. Renederowanie obiektu.
	plain.RenderMesh();

	// 6. Skonczenie uzywanie shadera.
	testShader.EndUsing();
}

int main(void)
{
	CreateObjects();

	mainLight.GetDirectionalShadowMap()->CreateFrameBufferAndTexture(1024, 1024);

	while (!window.ShouldClose())
	{
		mainCamera.Control(&window, 0.05f);

		window.PollEvents();

		window.ClearBuffer();

		MainRender(mainShader);

		window.SwapBuffers();
	}

}