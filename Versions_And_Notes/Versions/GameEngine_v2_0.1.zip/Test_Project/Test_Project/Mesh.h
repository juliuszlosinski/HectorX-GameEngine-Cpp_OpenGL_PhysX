#pragma once

#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>

class Mesh
{
public:
	// Konstruktor.
	Mesh();

	// Konstruktor + tworzenie siatki.
	Mesh(GLfloat* vertices, unsigned int numberOfVertices, unsigned int* indices, unsigned int numberOfIndices);

	// Tworzenie siatki.
	void CreateMesh(GLfloat* vertices, unsigned int numberOfVertices, unsigned int*  indices, unsigned int numberOfIndices);

	// Renderowanie siatki.
	void RenderMesh();

	// Czyszczenie siatki.
	void ClearMesh();

	// Uzyskaj indetyfikator VAO.
	GLuint GetVAO();

	// Uzyskaj identyfikator VBO.
	GLuint GetVBO();

	// Uzyskaj identyfikator IBO.
	GLuint GetIBO();

	// Uzyskaj ilosc wierzcholkow.
	unsigned int GetNumberOfVertices();

	// Uzyskaj ilosc indeksow.
	unsigned int GetNumberOfIndices();

	// Obliczanie srednich normali.
	static void CalcAverageNormals(unsigned int* indices, unsigned int indiceCount, GLfloat* vertices, unsigned int verticeCount, unsigned int vLength, unsigned int normalOffset);
	
	// Destruktor.
	~Mesh();
private:
	GLuint VAO; // Identyfikator bufora profilu.
	GLuint VBO; // Identyfikator bufora z danymi wierzcholkow (pozycja, kordynaty tesktury, normale).
	GLuint IBO; // Identyfikator bufora z indeksami, w jaki sposob laczyc punkty zeby stworzyc trojkaty.

	unsigned int numberOfVertices; // Ilosc wierzcholkow.
	unsigned int numberOfIndices;  // Ilosc indeksow.
};

