#pragma once

#include <glm\gtc\type_ptr.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include "ShadowMap.h"

class DirectionalLight
{
public:
	// Konstruktor.
	DirectionalLight(float red, float green, float blue, float ambientStrength, float diffuseStrength, float xDir, float yDir, float zDir);

	// Konstruktor.
	DirectionalLight();

	// Uzyskaj kolor swiatla.
	glm::vec3 GetLightColour();
	
	// Ustawienie koloru swiatla.
	void SetLightColour(float red, float green, float blue);

	// Uzyskaj sile swiatla otoczenia.
	float GetAmbientStrength();

	// Ustaw sile swiatla otoczenia.
	void SetAmbientStrenght(float ambientStrength);

	// Uzyskaj sile swiatla rozproszenia.
	float GetDiffuseStrength();

	// Ustaw sile swiatla rozproszenia.
	void SetDiffuseStrength(float diffuseStrength);

	// Uzyskaj kierunek padania swiatla.
	glm::vec3 GetDirection();

	// Ustaw kierunek padania swiatla.
	void SetDirection(float x, float y, float z);

	// Uzyskaj macierz transformacji do punktu widzenia przez swiatlo.
	glm::mat4 GetLigthSpaceMatrix();

	// Uzyskaj macierz widoku.
	glm::mat4 GetViewMatrix();

	// Uzyskaj macierz projekcji.
	glm::mat4 GetProjectionMatrix();

	// Uzyskaj kierunkowa mape cieni.
	ShadowMap* GetDirectionalShadowMap();

private:
	glm::vec3 lightColour;				// Kolor swiatla.
	glm::vec3 direction;				// Kierunek padania swiatla.
	float ambientStrength;				// Sila swiatla otoczenia.
	float diffuseStrength;				// Sila swiatla rozporoszenia.

	ShadowMap directionalShadowMap;		// Kierunkowa mapa cieni.

	glm::mat4 lightProj;	// Macierz transformacji swiatla.	
};

