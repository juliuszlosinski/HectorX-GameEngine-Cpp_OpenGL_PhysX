#include "Camera.h"

Camera::Camera()
{
	// 1. Ustawianie poczatkowych parametrow.
	position = glm::vec3(0, 0, 0);
	worldUp = glm::vec3(0, 1, 0);
	pitch = 0;
	yaw = 0;
	front = glm::vec3(0.0f, 0.0f, -1.0f);

	moveSpeed = 15;
	turnSpeed = 15;

	// 2. Aktualizowanie kamery.
	Update();
}

// Konstruktor.
Camera::Camera(glm::vec3 startPosition, glm::vec3 startUp, GLfloat startPitch, GLfloat startYaw, GLfloat startMoveSpeed, GLfloat startTurnSpeed)
{
	// 1. Ustawianie poczatkowych parametrow.
	position = startPosition;
	worldUp = startUp;
	pitch = startPitch;
	yaw = startYaw;
	front = glm::vec3(0.0f, 0.0f, -1.0f);

	moveSpeed = startMoveSpeed;
	turnSpeed = startTurnSpeed;

	// 2. Aktualizowanie kamery.
	Update();
}

// Obliczenie macierzy widoku.
glm::mat4 Camera::GetViewMatrix()
{
	// Zwrocenie macierzy.
	return glm::lookAt(position, position + front, up);
}

// Obliczanie nowych wartosci parametrow kamery.
void Camera::Update()
{
	// 1. Obliczanie nowych parametr�w naszego kierunku patrzenia.
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	front = glm::normalize(front);

	// 2. Obliczanie prawej strony.
	right = glm::normalize(glm::cross(front, worldUp));

	// 3. Obliczanie g�ry.
	up = glm::normalize(glm::cross(right, front));
}

// Kontrolowanie kamery za pomoca klawiatury.
void Camera::KeyControl(bool* keys, GLfloat deltaTime)
{
	// 1. Obliczanie predkosci ruchu.
	GLfloat velocity = moveSpeed * deltaTime;

	// 2. Zmiana pozycji.
	if (keys[GLFW_KEY_W])
	{
		position = position + front * velocity;
	}
	if (keys[GLFW_KEY_S])
	{
		position = position - front * velocity;
	}
	if (keys[GLFW_KEY_A])
	{
		position = position - right * velocity;
	}
	if (keys[GLFW_KEY_D])
	{
		position = position + right * velocity;
	}

	// 3. Aktualizowanie.
	Update();
}

// Kontrolowanie kamery za pomoca myszki.
void Camera::MouseControl(GLfloat xChange, GLfloat yChange)
{
	// 1. Ustawienie parametrow zmiany katow nachylenia wzgledem osi X oraz Y.
	yaw = yaw + xChange * turnSpeed;
	pitch = pitch + yChange * turnSpeed;

	// 2. Sprawdzanie kata nachylanie wzgledem osi X.
	if (pitch > 89.0f)
	{
		pitch = 89.0f;
	}

	if (pitch < -89.0f)
	{
		pitch = -89.0f;
	}

	// 3. Aktualizowanie parametrow kamery.
	Update();
}

// Calkowita kontrola.
void Camera::Control(Window* window, GLfloat deltaTime)
{
	KeyControl(window->GetKeys(), deltaTime);
	MouseControl(window->GetXChange(), window->GetYChange());
}

// Zworcenie pozycji kamery.
glm::vec3 Camera::GetPosition()
{
	return position;
}

// Zwrocenie gory kamery.
glm::vec3 Camera::GetUp()
{
	return up;
}

// Zwroc prawa strone kamery.
glm::vec3 Camera::GetRight()
{
	return right;
}

// Zwroc kierunek kamery.
glm::vec3 Camera::GetDirection()
{
	return front;
}

// Destuktor.
Camera::~Camera()
{
}

