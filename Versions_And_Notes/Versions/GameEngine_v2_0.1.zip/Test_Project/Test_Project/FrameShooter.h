#pragma once

#include <GL/glew.h>
#include "Shader.h"

/// <summary>
///	1. Przeslij parametry rozmariu portu.
/// 2. Zainicjalizuj bufor ramki z pustym buforem na kolory (tekstur�) oraz buforem renderowania.
/// 3. Uzyskaj zdjecie ramkie poprzez przeslanie shadera oraz wskaznika do funkcji tam gdzie ten shader jest u�ywany, �eby wyrenderowa� scene.
/// 4. Wskaznik do funkcji: Funkcja, ktora po prostu wykorzystuje owy shader zeby wyrenderowac scene.
/// </summary>

class FrameShooter
{
public:
	// Konstruktor.
	FrameShooter();

	// Konstrutkor.
	FrameShooter(int frameWidth, int frameHeight);

	// Inicjalizator.
	void Initialize();

	// Uzyskaj zdjecie.
	GLuint GetFrameShoot(Shader& shader, void (*Render) (Shader&));

private:
	int frameWidth;					// Dlugosc obrazu.
	int frameHeight;				// Wysokosc obrazu.

	unsigned int FBO;				// Identyfikator bufora ramki.
	unsigned int texColourBuffer;	// Identyfikator bufora z kolorami (tekstury).
	unsigned int RBO;				// Identyfikator bufora renderowania.
};

