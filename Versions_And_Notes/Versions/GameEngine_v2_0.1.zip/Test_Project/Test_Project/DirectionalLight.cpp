#include "DirectionalLight.h"

// Konstruktor.
DirectionalLight::DirectionalLight(float red, float green, float blue, float ambientStrength, float diffuseStrength, float xDir, float yDir, float zDir)
{
	// 1. Ustawienie koloru swiatla.
	lightColour = glm::vec3(red, green, blue);

	// 2. Ustawienie kierunku padani swiatla.
	direction = glm::vec3(xDir, yDir, zDir);

	// 3. Ustawienie mocy swiatla otoczenia.
	this->ambientStrength = ambientStrength;

	// 4. Ustawienie mocy swiatla rozproszenia.
	this->diffuseStrength = diffuseStrength;

	// 5. Ustawienie macierzy projekcji.
	float near_plane = 1.0f, far_plane = 7.5f;
	lightProj = glm::ortho(-20.0f, 20.0f, -20.0f, 20.0f, 0.1f, 100.0f);

	// 6. Utworzenie mapy cieni.
	directionalShadowMap = ShadowMap();
}

// Konstruktor.
DirectionalLight::DirectionalLight()
{
	// 1. Ustawienie koloru swiatla.
	lightColour = glm::vec3(1.0f, 1.0f, 1.0f);

	// 2. Ustawienie kierunku padani swiatla.
	direction = glm::vec3(0.0f, -1.0f, 0.0f);

	// 3. Ustawienie mocy swiatla otoczenia.
	this->ambientStrength = 0.5f;

	// 4. Ustawienie mocy swiatla rozproszenia.
	this->diffuseStrength = 1.0f;

	// 5. Ustawienie macierzy projekcji.
	float near_plane = 1.0f, far_plane = 7.5f;
	lightProj = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, near_plane, far_plane);

	// 6. Utworzenie mapy cieni.
	directionalShadowMap = ShadowMap();
}

// Uzyskaj kolor swiatla.
glm::vec3 DirectionalLight::GetLightColour()
{
	return lightColour;
}

// Ustawienie koloru swiatla.
void DirectionalLight::SetLightColour(float red, float green, float blue)
{
	lightColour = glm::vec3(red, green, blue);
}

// Uzyskaj sile swiatla otoczenia.
float DirectionalLight::GetAmbientStrength()
{
	return ambientStrength;
}

// Ustaw sile swiatla otoczenia.
void DirectionalLight::SetAmbientStrenght(float ambientStrength)
{
	this->ambientStrength = ambientStrength;
}

// Uzyskaj sile swiatla rozproszenia.
float DirectionalLight::GetDiffuseStrength()
{
	return diffuseStrength;
}

// Ustaw sile swiatla rozproszenia.
void DirectionalLight::SetDiffuseStrength(float diffuseStrength)
{
	this->diffuseStrength = diffuseStrength;
}

// Uzyskaj kierunek padania swiatla.
glm::vec3 DirectionalLight::GetDirection()
{
	return direction;
}

// Ustaw kierunek padania swiatla.
void DirectionalLight::SetDirection(float x, float y, float z)
{
	direction = glm::vec3(x, y, z);
}

// Uzyskaj macierz transformacji do punktu widzenia przez swiatlo.
glm::mat4 DirectionalLight::GetLigthSpaceMatrix()
{
	return lightProj * glm::lookAt(-direction, glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
}

// Uzyskaj macierz widoku.
glm::mat4 DirectionalLight::GetViewMatrix()
{
	return glm::lookAt(-direction, glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
}

// Uzyskaj macierz projekcji.
glm::mat4 DirectionalLight::GetProjectionMatrix()
{
	return lightProj;
}

// Uzyskaj kierunkowa mape cieni.
ShadowMap* DirectionalLight::GetDirectionalShadowMap()
{
	return &directionalShadowMap;
}