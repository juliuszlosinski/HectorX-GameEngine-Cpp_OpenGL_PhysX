#include "PointLight.h"

PointLight::PointLight()
{
    // Ustawienie parametrow swiatla.

    // 1. Kolor.
    lightColour = glm::vec3(1.0f, 1.0f, 1.0f);

    // 2. Pozycja.
    position = glm::vec3(0.0f, 0.0f, 0.0f);

    // 3. Moc oswietlenia otoczenia.
    ambientStrength = 0.5f;

    // 4. Moc oswietlenia rozproszonego.
    diffuseStrength = 1.0f;

    // 5. Parametr kwadratowy.
    quadratic = 2;

    // 6. Parametr liniowy.
    linear = 1;

    // 7. Parametr staly.
    constant = 1;
}

PointLight::PointLight(float red, float green, float blue,
    float ambientStrength, float diffuseStrength,
    float quadratic, float linear, float constant,
    float xPos, float yPos, float zPos)
{
    // Ustawienie parametrow swiatla.

    // 1. Kolor.
    lightColour = glm::vec3(red, green, blue);

    // 2. Pozycja.
    position = glm::vec3(xPos, yPos, zPos);

    // 3. Moc oswietlenia otoczenia.
    this->ambientStrength = ambientStrength;

    // 4. Moc oswietlenia rozproszonego.
    this->diffuseStrength = diffuseStrength;

    // 5. Parametr kwadratowy.
    this->quadratic = quadratic;

    // 6. Parametr liniowy.
    this->linear = linear;

    // 7. Parametr staly.
    this->constant = constant;
}


// Zwroc kolor swiatla.
glm::vec3 PointLight::GetLightColour()
{
    return lightColour;
}

// Ustaw kolor swiatla.
void PointLight::SetLightColour(float red, float green, float blue)
{
    lightColour = glm::vec3(red, green, blue);
}

// Zwroc pozycje zrodla swiatla.
glm::vec3 PointLight::GetPosition()
{
    return position;
}

// Ustaw pozycje swiatla.
void PointLight::SetPosition(float x, float y, float z)
{
    position = glm::vec3(x, y, z);
}

// Zwroc moc swiatla otoczenia.
float PointLight::GetAmbientStrength()
{
    return ambientStrength;
}

// Ustaw moc oswietlenia otoczenia.
void PointLight::SetAmbientStrength(float ambientStrength)
{
    this->ambientStrength = ambientStrength;
}

// Zwroc moc swiatla rozproszenia.
float PointLight::GetDiffuseStrength()
{
    return diffuseStrength;
}

// Ustaw moc swiatla otoczenia.
void PointLight::SetDiffuseStrength(float diffuseStrength)
{
    this->diffuseStrength = diffuseStrength;
}

// Zwroc staly parametr.
float PointLight::GetConstant()
{
    return constant;
}

// Ustaw staly parametr.
void PointLight::SetConstant(float constant)
{
    this->constant = constant;
}

// Zwroc liniowy parametr.
float PointLight::GetLinear()
{
    return linear;
}

// Ustaw liniowy parametr.
void PointLight::SetLinear(float linear)
{
    this->linear = linear;
}

// Zwroc kwadratowy parametr.
float PointLight::GetQuadratic()
{
    return quadratic;
}

// Ustaw kwadratowy parametr.
void PointLight::SetQuadratic(float quadratic)
{
    this->quadratic = quadratic;
}

// Destruktor.
PointLight::~PointLight()
{

}
