#pragma once

#include <glm\gtc\type_ptr.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "Window.h"

class Camera
{
public:
	// Konstruktor.
	Camera();

	// Konstruktor.
	Camera(glm::vec3 startPosition, glm::vec3 startUp, GLfloat startPitch, GLfloat startYaw, GLfloat startMoveSpeed, GLfloat startTurnSpeed);

	// Kontrola za pomoca klawiatury.
	void KeyControl(bool* keys, GLfloat deltaTime);

	// Kontrola za pomoca myszki.
	void MouseControl(GLfloat xChange, GLfloat yChange);

	// Calkowita kontrola.
	void Control(Window* window, GLfloat deltaTime);

	// Zwroc pozycje kamery.
	glm::vec3 GetPosition();

	// Zwroc gore kamery.
	glm::vec3 GetUp();

	// Zwroc prawo kamery.
	glm::vec3 GetRight();

	// Zwroc kierunek na przeciwko kamery.
	glm::vec3 GetDirection();

	// Zwroc macierz widoku.
	glm::mat4 GetViewMatrix();

	// Destruktor.
	~Camera();
private:
	glm::vec3 position;		// Pozycja kamery.
	glm::vec3 front;		// Kierunek na przeciwko kamery.
	glm::vec3 up;			// Kierunek na gore od kamery.
	glm::vec3 right;		// Kierunek na prawo.

	glm::vec3 worldUp;		// Kierunek swiata do gory.

	GLfloat pitch;			// Kat odchylenia na osi X.
	GLfloat yaw;			// Kat odchylenia na osi Y.

	GLfloat moveSpeed;		// Szybkosc poruszania sie.
	GLfloat turnSpeed;		// Szybkosc obrotu.

	// Aktualizowanie kamery.
	void Update();
};

