#pragma once

#include <GL/glew.h>
#include "CommonValues.h"

class Texture
{
public:
	// Konstruktor.
	Texture();

	// Konstruktor + zaladowanie tekstury.
	Texture(bool alpha, const char* fileLocation);

	// Utworzenie zaladowanie tekstury.
	bool LoadTexture(const char* fileLocation);

	// Utworzenie zaladowanie tekstury z kanalem alpha.
	bool LoadTextureA(const char* fileLocation);

	// Uzywanie tekstury.
	void UseTexture(GLuint textureUnit);

	// Uzyskaj identyfikator tekstury.
	GLuint GetTextureID();

	// Uzyskaj dlugosc tekstury.
	int GetWidth();

	// Uzyskaj wysokosc tekstury.
	int GetHeight();

	// Uzyskaj ilosc kanalow
	int GetNumberOfChannels();

private:
	GLuint textureID;		// Identyfikator tekstury.

	int width;				// Dlugosc obrazka.
	int height;				// Wysokosc obrazka.
	int numberOfChannels;	// Ilosc kanalow.

};

