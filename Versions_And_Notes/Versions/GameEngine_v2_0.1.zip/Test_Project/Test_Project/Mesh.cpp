#include "Mesh.h"

// Konstruktor.
Mesh::Mesh()
{
	// 1. Ustawienie parametrow domyslnych.
	VAO = 0;
	VBO = 0;
	IBO = 0;
	numberOfVertices = 0;
	numberOfIndices = 0;
}

// Konstruktor + tworzenie siatki.
Mesh::Mesh(GLfloat* vertices, unsigned int numberOfVertices, unsigned int* indices, unsigned int numberOfIndices)
{
	// Tworzenie siatki.
	CreateMesh(vertices, numberOfVertices, indices, numberOfIndices);
}

// Tworzenie siatki.
void Mesh::CreateMesh(GLfloat* vertices, unsigned int numberOfVertices, unsigned int* indices, unsigned int numberOfIndices)
{
	// 0. Zapisanie danych.
	this->numberOfIndices = numberOfIndices;
	this->numberOfVertices = numberOfVertices;

	// 1. Utworzenie VAO.
	glGenVertexArrays(1, &VAO);

	// 2. Ustaw roboczy VAO. -> BINDING VAO.
	glBindVertexArray(VAO);

	// 3. Utworzenie  IBO.
	glGenBuffers(1, &IBO);

	// 4. Ustaw roboczy IBO. -> BINDING IBO.
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);

	// 5. Przeslij dane do bufora.
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, numberOfIndices * sizeof(indices[0]), indices, GL_STATIC_DRAW);

	// 6. Utworzenie VBO.
	glGenBuffers(1, &VBO);

	// 7. Ustawienie roboczego VBO. -> UNBINDING VBO.
	glBindBuffer(GL_ARRAY_BUFFER, VBO);

	// 8. Przeslanie danych.
	glBufferData(GL_ARRAY_BUFFER, numberOfVertices * sizeof(vertices[0]), vertices, GL_STATIC_DRAW);

	// 9. Ustawienie atrybutow bufora.
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertices[0])*8, 0);

	// 10. Aktywowanie atrybutu.
	glEnableVertexAttribArray(0);

	// 11. Ustawienie atrybutow bufora.
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(vertices[0]) * 8, (void*)(3 * sizeof(vertices[0])));

	// 12. Aktywowanie atrybutu.
	glEnableVertexAttribArray(1);

	// 13. Ustawienie atrybutu.
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(vertices[0]) * 8, (void*)(5 * sizeof(vertices[0])));

	// 14. Aktywowanie atrybutu.
	glEnableVertexAttribArray(2);

	// 15. Zdjecie VBO -> UNBINDING VBO.
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// 16. Zdjecie IBO -> UNBINDING IBO.
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	// 17. Zdjecie VAO. -> UNBINDING VAO.
	glBindVertexArray(0);
}

void Mesh::RenderMesh()
{
	// 1. Ustawienie VAO.
	glBindVertexArray(VAO);

		// 2. Ustawienie IBO.
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);

			// 3. Wywolanie strumienia renderowania z przeslanym danymi oraz VAO/IBO.
			glDrawElements(GL_TRIANGLES, numberOfIndices, GL_UNSIGNED_INT, 0);
	
		// 4. Zwolnienie IBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	// 5. Zwolnienie VAO.
	glBindVertexArray(0);
}

// Obliczanie srednich normali.
void Mesh::CalcAverageNormals(unsigned int* indices, unsigned int indiceCount, GLfloat* vertices, unsigned int verticeCount, unsigned int vLength, unsigned int normalOffset)
{
	for (size_t i = 0; i < indiceCount; i += 3)
	{
		// 1. Mnozymy przez vLength zeby uzyskac dostep do pierwszej wartosci wierzcholka.
		unsigned int in0 = indices[i] * vLength;
		unsigned int in1 = indices[i + 1] * vLength;
		unsigned int in2 = indices[i + 2] * vLength;

		// 2. Zdefiniowanie krawedzi (polaczenie dwoch pozycji zeby stworzyc linie).
		// 2.1 Stworzenie takich dwoch krawedzi.
		glm::vec3 v1(vertices[in1] - vertices[in0], vertices[in1 + 1] - vertices[in0 + 1], vertices[in1 + 2] - vertices[in0 + 2]);
		glm::vec3 v2(vertices[in2] - vertices[in0], vertices[in2 + 1] - vertices[in0 + 1], vertices[in2 + 2] - vertices[in0 + 2]);

		// 2.2 Uzycie cross product na tych dwoch liniach zeby uzyskac normal.
		glm::vec3 normal = glm::cross(v1, v2);
		normal = glm::normalize(normal);

		// 3. Dodanie offsetu zeby przejsc do normalnego.
		in0 += normalOffset; in1 += normalOffset; in2 += normalOffset;

		// 4. Dodawanie normali.
		vertices[in0] += normal.x; vertices[in0 + 1] += normal.y; vertices[in0 + 2] += normal.z;
		vertices[in1] += normal.x; vertices[in1 + 1] += normal.y; vertices[in1 + 2] += normal.z;
		vertices[in2] += normal.x; vertices[in2 + 1] += normal.y; vertices[in2 + 2] += normal.z;
	}

	for (size_t i = 0; i < verticeCount / vLength; i++)
	{
		// 5. Usrednianie.
		unsigned int nOffset = i * vLength + normalOffset;
		glm::vec3 vec(vertices[nOffset], vertices[nOffset + 1], vertices[nOffset + 2]);
		vec = glm::normalize(vec);
		vertices[nOffset] = vec.x; vertices[nOffset + 1] = vec.y; vertices[nOffset + 2] = vec.z;
	}
}

// Likwidacja siatki.
void Mesh::ClearMesh()
{
	// Czyszczenie siatki.
	if (VAO != 0)
	{
		glDeleteBuffers(1, &VAO);
		VAO = 0;
	}
	if (IBO != 0)
	{
		glDeleteBuffers(1, &IBO);
		IBO = 0;
	}
	if (VBO != 0)
	{
		glDeleteBuffers(1, &VBO);
		VBO = 0;
	}
}

// Uzyskaj identyfikator VAO.
GLuint Mesh::GetVAO()
{
	return VAO;
}

// Uzyskaj identyfikator IBO.
GLuint Mesh::GetIBO()
{
	return VAO;
}

// Uzyskaj identyfikator VBO.
GLuint Mesh::GetVBO()
{
	return VBO;
}

// Uzyskaj ilosc wierzcholkow.
unsigned int Mesh::GetNumberOfVertices()
{
	return numberOfVertices;
}

// Uzyskaj ilosc indeksow.
unsigned int Mesh::GetNumberOfIndices()
{
	return numberOfIndices;
}

Mesh::~Mesh()
{
	// Czyszczenie siatki.
	ClearMesh();
}
