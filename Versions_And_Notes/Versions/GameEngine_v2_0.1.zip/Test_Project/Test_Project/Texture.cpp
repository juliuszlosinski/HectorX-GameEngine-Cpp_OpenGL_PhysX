#include "Texture.h"

// Konstruktor.
Texture::Texture()
{
	// 1. Ustawienie parametrow domyslnych.
	textureID = 0;
	width = 0;
	height = 0;
	numberOfChannels = 0;
}

Texture::Texture(bool alpha, const char* fileLocation)
{
	// Zalodawnie tekstury relatywnie czy ma ona kanal alpha
	if (alpha)
	{
		LoadTextureA(fileLocation);
	}
	else
	{
		LoadTexture(fileLocation);
	}
}

// Utworzenie/ zalodowanie tekstury.
bool Texture::LoadTexture(const char* fileLocation)
{
	// 1. Zaladowanie obrazka.
	unsigned char* img = stbi_load(fileLocation, &width, &height, &numberOfChannels, 0);
	
	// 2. Sprawdzenie czy sie powiodlo.
	if (!img)
	{
		// NIE.
		printf("Failed to load a texture: '%s'", img);

		return false;
	}
	else
	{
		// TAK.

		// 1. Generowanie tekstury.
		glGenTextures(1, &textureID);

		// 2. Ustawienie roboczej tekstury.
		glBindTexture(GL_TEXTURE_2D, textureID);

		// 3. Ustawienie parametrow tekstury.

		// 3.1 Owijanie tekstury.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	
		// 3.2 Filtry.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// 4. Zaladowanie tekstury.
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
		
		// 5. Generowanie mipmapy.
		glGenerateMipmap(GL_TEXTURE_2D);

		// 6. Zdjecie tekstury roboczej.
		glBindTexture(GL_TEXTURE_2D, 0);

		// 7. Zwolnienie ladownika obrazka.
		stbi_image_free(img);

		return true;
	}
}

// Utworzenie/ zalodowanie tekstury z kana�em alpha.
bool Texture::LoadTextureA(const char* fileLocation)
{
	// 1. Zaladowanie obrazka.
	unsigned char* img = stbi_load(fileLocation, &width, &height, &numberOfChannels, 0);

	// 2. Sprawdzenie czy sie powiodlo.
	if (!img)
	{
		// NIE.
		printf("Failed to load a texture: '%s'", img);

		return false;
	}
	else
	{
		// TAK.

		// 1. Generowanie tekstury.
		glGenTextures(1, &textureID);

		// 2. Ustawienie roboczej tekstury.
		glBindTexture(GL_TEXTURE_2D, textureID);

		// 3. Ustawienie parametrow tekstury.

		// 3.1 Owijanie tekstury.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// 3.2 Filtry.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// 4. Zaladowanie tekstury.
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img);

		// 5. Generowanie mipmapy.
		glGenerateMipmap(GL_TEXTURE_2D);

		// 6. Zdjecie tekstury roboczej.
		glBindTexture(GL_TEXTURE_2D, 0);

		// 7. Zwolnienie ladownika obrazka.
		stbi_image_free(img);

		return true;
	}
}

// Uzywanie tekstury dla danej jednostki.
void Texture::UseTexture(GLuint textureUnit)
{
	// Aktywowanie tekstury dla danej jednsotki.
	glActiveTexture(GL_TEXTURE0 + textureUnit);
	glBindTexture(GL_TEXTURE_2D, textureID);
}

// Uzyskaj identyfikator tekstury.
GLuint Texture::GetTextureID()
{
	return textureID;
}

// Uzyskaj dlugosc tekstury.
int Texture::GetWidth()
{
	return width;
}

// Uzyskaj wysokosc tekstury.
int Texture::GetHeight()
{
	return height;
}

// Uzyskaj ilosc kanalow.
int Texture::GetNumberOfChannels()
{
	return numberOfChannels;
}
