#pragma once

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <string>

class Window
{
public:
	
	// Konstruktor.
	Window();

	// Destuktor.
	Window(GLuint width, GLuint height,const char* title);

	// 1. Inicjalizator okna.
	int Initialize();

	// 2. Czy okno powinno sie zamknac.
	int ShouldClose();

	// 3. Wyczekiwanie na zdarzenia.
	void PollEvents();

	// 4. Czysczenie bufora.
	void ClearBuffer();

	// 5. Zamiana buforow.
	void SwapBuffers();

	// Czy przycisk jest wcisniety.
	bool IsKeyPressed(int keyCode);

	// Czy przycisk jest zwolniony.
	bool IsKeyReleased(int keyCode);

	// Uzyskaj dlugosc bufora.
	int GetBufferWidth();

	// Uzyskaj wysokosc bufora.
	int GetBufferHeight();

	// Uzyskaj dlugosc okna.
	GLuint GetWindowWidth();

	// Uzyskaj wysokosc okna.
	GLuint GetWindowHeight();

	// Uzyskanie delty X.
	GLfloat GetXChange();

	// Uzyskanie delty Y.
	GLfloat GetYChange();

	// Uzyskaj tytul okna.
	const char* GetTitle();

	// Utworz oddzwonienia na zdarzenia.
	void CreateCallBacks(); 

	// Uzyskanie dostep do wcisnietych klawiszy.
	bool* GetKeys();

	// Ustawienie rozmiaru portu ogladacza.
	void SetViewPort(int x, int y, int width, int height);

	// Destruktor.
	~Window();
private:
	int bufferWidth;  // Dlugosc bufora ramki w pikselach.
	int bufferHeight; // Wysokosc bufora ramki w pikselach.

	GLuint windowWidth;		 // Dlugosc okna.
	GLuint windowHeight;		 // Wysokosc okna.
	
	const char* title;   // Tytul okna.
	
	GLFWwindow* window;	 // Okno.

	bool keys[1024];	 // Klawisze, ktore beda wciskane prze uzytkownika.

	GLfloat lastX;		// Ostatnie x.
	GLfloat lastY;		// Ostatnie y.
	GLfloat xChange;	// Delta x.
	GLfloat yChange;	// Delta y.
	bool mousedFirstMoved; // Pierwsze poruszenie myszka.

	// Obsluga klawiszy.
	static void handleKeys(GLFWwindow* window, int key, int code, int action, int mode); 

	// Obsluga myszki.
	static void handleMouse(GLFWwindow* window, double xPos, double yPos);
};

