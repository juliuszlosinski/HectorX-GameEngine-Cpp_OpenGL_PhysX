#include "FrameShooter.h"

// Konstrutkor.
FrameShooter::FrameShooter()
{
	// Ustawienie parametrow.
	frameWidth = 0;
	frameHeight = 0;
}

// Konstruktor.
FrameShooter::FrameShooter(int frameWidth, int frameHeight)
{
	// Ustawienie parametrow.
	this->frameWidth = frameWidth;
	this->frameHeight = frameHeight;
}

// Inicjalizator.
void FrameShooter::Initialize()
{
	// 1. Generowanie bufora ramki oraz ustawienie go jako roboczego.
	glGenFramebuffers(1, &FBO);
	glBindFramebuffer(GL_FRAMEBUFFER, FBO);

	// 2. Generowanie tekstury/ bufora na kolor oraz ustawianie jego atrybutow.
	glGenTextures(1, &texColourBuffer);
	glBindTexture(GL_TEXTURE_2D, texColourBuffer);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frameWidth, frameHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// 3. Zalaczenie pustego bufora/ tekstury na kolory do bufora ramki.
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, texColourBuffer, 0);

	// 4. Utworzenie bufora renderowania dla glebi oraz szablonu.
	glGenRenderbuffers(1, &RBO);
	glBindRenderbuffer(GL_RENDERBUFFER, RBO);
	glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, frameWidth, frameHeight);

	// 5. Zalaczenie bufora randerowania do bufora ramki.
	glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, RBO);

	// 6. Powrot do bufora podstawowego.
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

// Uzyskaj zdjecie ramki.
GLuint FrameShooter::GetFrameShoot(Shader& shader, void (*Render) (Shader&))
{
	// 1. Ustawienie bufora ramki roboczego.
	glBindFramebuffer(GL_FRAMEBUFFER, FBO);

	// 2. Ustawienie testowania glebokosci.
	glEnable(GL_DEPTH_TEST);

	// 3. Wyczyszczenie poprzedniej ramki.
	glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// 4. Renderowanie glownej sceny.
	Render(shader);

	// 5. Zejscie z tego bufora ramki.
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	
	// 6. Wylaczenie testowania glebi.
	glDisable(GL_DEPTH_TEST); // disable depth test so screen-space quad isn't discarded due to depth test.

	// 7. Wyczyszcenie sceny.
	glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	return texColourBuffer;
}