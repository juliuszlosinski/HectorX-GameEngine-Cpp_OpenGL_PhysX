#pragma once

#include "CommonValues.h"
#include "Mesh.h"
#include <vector>
#include <string>
#include "Shader.h"
#include <glm\gtc\type_ptr.hpp>
#include <glm\gtc\matrix_transform.hpp>

class Skybox
{
public:
	// Konstrutkor.
	Skybox();

	// Konstrutkor.
	Skybox(std::vector<std::string> faces);

	// Zaladowanie skybox'a.
	void LoadSkybox(std::vector<std::string> faces);

	// Renderowanie.
	void Render(glm::mat4 view, glm::mat4 projection);
private:
	Mesh cubeMesh;			// Siatka szescienna.
	GLuint textureId;		// Identyfikator tekstury szesciennej.
	Shader cubeShader;		// Shader do rysowanie szescianu.
};

