#include "Skybox.h"

// Konstrutkor.
Skybox::Skybox()
{
	cubeMesh = Mesh();
}

// Konstrutkor.
Skybox::Skybox(std::vector<std::string> faces)
{
	LoadSkybox(faces);
}

// Zaladowanie skybox'a.
void Skybox::LoadSkybox(std::vector<std::string> faces)
{
	// TEKSTURA:---------------------------------------------

	// 1. Utworzenie tekstury.
	glGenTextures(1, &textureId);

	// 2. Ustawienie tekstury jako roboczej.
	glBindTexture(GL_TEXTURE_CUBE_MAP, textureId);

	// 3. Wczytywanie tekstur do mapy szeciennej oraz zapamietywanie ich parametrow.
	int width;			// Dlugosc.
	int height;			// Wysokosc.
	int nrOfChannels;	// Ilosc kanalow.

	for (size_t i = 0; i < faces.size(); i++)
	{
		unsigned char* data = stbi_load(faces[i].c_str(), &width, &height, &nrOfChannels, 0);
		if (data)
		{
			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
			stbi_image_free(data);
		}
		else
		{
			printf("Cubemap texture failed to load at path: %s", faces[i]);
			stbi_image_free(data);
		}
	}

	// 4. Ustawianie paremetrow tekstury.
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);

	// SIATKA:---------------------------------------

	// 1. Utworzenie indeksow.
	unsigned int skyboxIndices[] = {
		// FRONT
		0, 1, 2,
		2, 1, 3,
		// RIGHT
		2, 3, 5,
		5, 3, 7,
		// BACK
		5, 7, 4,
		4, 7, 6,
		// LEFT
		4, 6, 0,
		0, 6, 1,
		// TOP
		4, 0, 5,
		5, 0, 2,
		// BOTTOM
		1, 6, 3,
		3, 6, 7
	};

	// 2. Utworzenie wierzcholkow.
	float skyboxVertices[] = {
		-1.0f, 1.0f, -1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 0
		-1.0f, -1.0f, -1.0f,	0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 1
		1.0f, 1.0f, -1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 2
		1.0f, -1.0f, -1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 3

		-1.0f, 1.0f, 1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 4
		1.0f, 1.0f, 1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 5
		-1.0f, -1.0f, 1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 6
		1.0f, -1.0f, 1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f  // 7
	};

	// 3. Utworzenie siatki.
	cubeMesh = Mesh();
	cubeMesh.CreateMesh(skyboxVertices, 64, skyboxIndices, 36);

	// SHADER -------------------
	cubeShader = Shader();
	cubeShader.CreateFromFiles("Shaders/skybox.vt", "Shaders/skybox.frag");
}

// Renderowanie skybox'a.
void Skybox::Render(glm::mat4 view, glm::mat4 projection)
{
	glm::mat4 viewMatrix = glm::mat4(glm::mat3(view));

	// 1. Wylaczenie maski glebi.
	glDepthMask(GL_FALSE);

	// 2. Uzywanie shadera.
	cubeShader.UseShader();

	// 3. Przeslanie uniformow.

	// 3.1 Tesktury.

	// 3.1.1 Powiazanie probkera z jednostka tekstury o id 0.
	cubeShader.BindTextureSamplerUniformToTextureUnit("skyboxTexture", 0);

	// 3.1.2 Powiazanie jednostki tekstury o id 0 z tekstura (mapa szescienna).
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_CUBE_MAP, textureId);

	// 3.2 Macierze.

	// 3.2.1 Widoku.
	cubeShader.AttachUniformMatrix4x4("view", viewMatrix);

	// 3.2.2 Projekcji.
	cubeShader.AttachUniformMatrix4x4("projection", projection);

	// 4. Renderowanie siatki.
	cubeMesh.RenderMesh();

	// 5. Przestanie uzywanie shadera.
	cubeShader.EndUsing();

	// 6. Wlaczenie maski glebi.
	glDepthMask(GL_TRUE);
}
