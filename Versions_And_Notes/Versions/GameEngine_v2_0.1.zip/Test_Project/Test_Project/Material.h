#pragma once

class Material
{
public:
	// Konstruktor.
	Material();

	// Konstruktor.
	Material(float shininess);

	// Zwrocenie jasnosci materialu.
	float GetShininess();

private:
	float shininess; // Jasnosc materialu.
};

